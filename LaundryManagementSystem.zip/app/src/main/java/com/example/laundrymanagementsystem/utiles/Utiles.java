package com.example.laundrymanagementsystem.utiles;

import com.example.laundrymanagementsystem.model.OrderInformation;

import java.util.ArrayList;

public class Utiles {

    public static ArrayList<OrderInformation> orderInformations =new ArrayList<>();

}
